namespace InventoryMaintenance
{
    public partial class frmInventoryMaint : Form
    {
        public frmInventoryMaint()
        {
            InitializeComponent();
        }

        // Add a statement here that declares the list of items.
        private List<InventoryItem> items = new List<InventoryItem>();

        private void frmInventoryMaint_Load(object sender, EventArgs e)
        {
            // Add a statement here that gets the list of items.
            FillItemListBox();
        }

        private void FillItemListBox()
        {
            lstItems.Items.Clear();
            // Add code here that loads the list box with the items in the list.
            lstItems.Items.Clear();

            // Iterate through the items list and add each item to the list box
            foreach (InventoryItem item in items)
            {
                // You can use GetDisplayText() or other appropriate methods
                // to format the item's display text.
                string displayText = item.GetDisplayText(); // Replace with the appropriate method

                lstItems.Items.Add(displayText);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Add code here that creates an instance of the New Item form

            // and then gets a new item from that form.
            // Create an instance of the New Item form
            frmNewItem newItemForm = new frmNewItem();

            // Display the New Item form as a dialog
            DialogResult result = newItemForm.ShowDialog();

            // Check the result of the dialog
            if (result == DialogResult.OK)
            {
                // The user clicked the OK button in the frmNewItem form (assuming you have an OK button)
                // You can access the newly created item by calling newItemForm.GetNewItem()
                InventoryItem newItem = newItemForm.GetNewItem();

                // Now you can proceed to add the new item to your list or perform other actions.
                if (newItem != null)
                {
                    // Add the new item to your list or perform any desired actions.
                    items.Add(newItem); // Assuming 'items' is your list of InventoryItems.
                                        // Refresh the Items list box or update your data display.
                    FillItemListBox();
                }
            }
            else
            {
                // The user closed the frmNewItem form without adding a new item (e.g., they clicked Cancel)
                // Handle this situation as needed.
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int selectedIndex = lstItems.SelectedIndex;

            if (selectedIndex != -1)
            {
                // Prompt the user for confirmation
                DialogResult result = MessageBox.Show("Are you sure you want to delete this item?", "Confirm Deletion", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    // User confirmed deletion
                    // Remove the selected item from the list
                    items.RemoveAt(selectedIndex); // Assuming 'items' is your list of InventoryItems

                    // Save the updated list (you can use your SaveItems method or any other appropriate method)
                    InventoryDB.SaveItems(items);

                    // Refresh the list box
                    FillItemListBox();
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}