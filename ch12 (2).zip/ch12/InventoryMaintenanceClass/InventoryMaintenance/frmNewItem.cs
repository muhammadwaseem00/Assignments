﻿namespace InventoryMaintenance
{
    public partial class frmNewItem : Form
    {
        public frmNewItem()
        {
            InitializeComponent();
        }

        // Add a statement here that declares the inventory item.
        private InventoryItem newItem;


        // Add a method here that gets and returns a new item.

        public InventoryItem GetNewItem()
        {
            // Check if the data entered is valid
            if (IsValidData())
            {
                // Create a new InventoryItem based on user input
                int itemNo = int.Parse(txtItemNo.Text);
                string description = txtDescription.Text;
                decimal price = decimal.Parse(txtPrice.Text);

                // Create a new InventoryItem object
                newItem = new InventoryItem(itemNo, description, price);

                // Return the new item
                return newItem;
            }
            else
            {
                // Data is not valid, return null or handle the error
                return null;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (IsValidData())
            {
                // Create a new item based on user input
                int itemNo = int.Parse(txtItemNo.Text);
                string description = txtDescription.Text;
                decimal price = decimal.Parse(txtPrice.Text);

                // Create a new InventoryItem object
                newItem = new InventoryItem(itemNo, description, price);

                // Set the DialogResult to OK to indicate that the user clicked the OK button
                this.DialogResult = DialogResult.OK;

                // Close the form
                this.Close();
            }
        }

        private bool IsValidData()
        {
            bool success = true;
            string errorMessage = "";

            errorMessage += Validator.IsPresent(txtItemNo.Text, "Item no");
            errorMessage += Validator.IsInt32(txtItemNo.Text, "Item no");
            errorMessage += Validator.IsPresent(txtDescription.Text, "Description");
            errorMessage += Validator.IsPresent(txtPrice.Text, "Price");
            errorMessage += Validator.IsDecimal(txtPrice.Text, "Price");

            if (errorMessage != "")
            {
                success = false;
                MessageBox.Show(errorMessage, "Entry Error");
            }
            return success;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmNewItem_Load(object sender, EventArgs e)
        {

        }
    }
}