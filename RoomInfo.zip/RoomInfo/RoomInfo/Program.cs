﻿using System;

class RoomInfo
{
    private double length;
    private double width;
    private bool hasTV;
    private static double houseSize;

    // Constructors
    public RoomInfo()
    {
        length = 0;
        width = 0;
        hasTV = false;
        CalcRoomSize();  // This method can now be accessed from here
    }

    public RoomInfo(double l, double w, bool tv)
    {
        length = l;
        width = w;
        hasTV = tv;
        CalcRoomSize();
    }

    // Properties
    public double Length
    {
        get { return length; }
        set { length = value; }
    }

    public double Width
    {
        get { return width; }
        set { width = value; }
    }

    public bool HasTV
    {
        get { return hasTV; }
        set { hasTV = value; }
    }

    public static double HouseSize
    {
        get { return houseSize; }
    }

    // Function to calculate room size and update house size
    public void CalcRoomSize()  // Make this method public
    {
        double roomSize = length * width;
        houseSize += roomSize;
    }
}

class RoomInfoDemo
{
    static void Main()
    {
        RoomInfo[] rooms = new RoomInfo[4];

        for (int i = 0; i < 4; i++)
        {
            rooms[i] = new RoomInfo();
            GetData(rooms[i], i + 1);
        }

        DisplayRoomAndHouseSize(rooms);
        DisplayNumberOfRoomsWithTV(rooms);
    }

    static void GetData(RoomInfo room, int roomNumber)
    {
        Console.WriteLine($"Enter information for Room {roomNumber}:");
        Console.Write("Enter length: ");
        room.Length = double.Parse(Console.ReadLine());

        Console.Write("Enter width: ");
        room.Width = double.Parse(Console.ReadLine());

        Console.Write("Is there a TV in the room? (Y/N): ");
        room.HasTV = (Console.ReadLine().ToUpper() == "Y");

        // Calculate room size and update house size
        room.CalcRoomSize();  // Now accessible as it's public
    }

    static void DisplayRoomAndHouseSize(RoomInfo[] rooms)
    {
        Console.WriteLine("\nRoom and House Sizes:");
        for (int i = 0; i < rooms.Length; i++)
        {
            Console.WriteLine($"Room {i + 1} Size: {rooms[i].Length} x {rooms[i].Width}");
        }
        Console.WriteLine($"Total House Size: {RoomInfo.HouseSize}");
    }

    static void DisplayNumberOfRoomsWithTV(RoomInfo[] rooms)
    {
        int count = 0;
        foreach (var room in rooms)
        {
            if (room.HasTV)
            {
                count++;
            }
        }
        Console.WriteLine($"\nNumber of Rooms with TV: {count}");
    }
}
